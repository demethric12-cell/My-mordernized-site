// Simple interactivity placeholder
document.addEventListener('DOMContentLoaded', function () {
  // future: add cart, filters, or animations
  console.log('Dekpoy Enterprise (modernized) loaded.');
});
