---
title: Green Pepper
price: 2.50
image: /assets/images/green-pepper.jpg
description: Fresh, organic green peppers from our farm.
video: 
---

Picked and packed within 24 hours of harvest.
